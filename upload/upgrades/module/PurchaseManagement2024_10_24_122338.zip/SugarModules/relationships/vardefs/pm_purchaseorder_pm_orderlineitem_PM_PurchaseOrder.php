<?php
// created: 2024-10-24 12:23:38
$dictionary["PM_PurchaseOrder"]["fields"]["pm_purchaseorder_pm_orderlineitem"] = array (
  'name' => 'pm_purchaseorder_pm_orderlineitem',
  'type' => 'link',
  'relationship' => 'pm_purchaseorder_pm_orderlineitem',
  'source' => 'non-db',
  'module' => 'PM_OrderLineItem',
  'bean_name' => 'PM_OrderLineItem',
  'side' => 'right',
  'vname' => 'LBL_PM_PURCHASEORDER_PM_ORDERLINEITEM_FROM_PM_ORDERLINEITEM_TITLE',
);
